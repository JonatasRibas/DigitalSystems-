﻿
namespace Padaria
{
    partial class frm_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_menu));
            this.btn_caixa = new System.Windows.Forms.Button();
            this.btn_fechar = new System.Windows.Forms.Button();
            this.btn_prod = new System.Windows.Forms.Button();
            this.btn_client = new System.Windows.Forms.Button();
            this.btn_func = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_caixa
            // 
            this.btn_caixa.BackColor = System.Drawing.Color.Black;
            this.btn_caixa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_caixa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_caixa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_caixa.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_caixa.ForeColor = System.Drawing.Color.White;
            this.btn_caixa.Image = ((System.Drawing.Image)(resources.GetObject("btn_caixa.Image")));
            this.btn_caixa.Location = new System.Drawing.Point(592, 44);
            this.btn_caixa.Name = "btn_caixa";
            this.btn_caixa.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_caixa.Size = new System.Drawing.Size(225, 175);
            this.btn_caixa.TabIndex = 3;
            this.btn_caixa.Text = "Caixa";
            this.btn_caixa.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_caixa.UseVisualStyleBackColor = false;
            this.btn_caixa.Click += new System.EventHandler(this.btn_caixa_Click);
            // 
            // btn_fechar
            // 
            this.btn_fechar.BackColor = System.Drawing.Color.Transparent;
            this.btn_fechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_fechar.Font = new System.Drawing.Font("Century Gothic", 25.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_fechar.Location = new System.Drawing.Point(289, 488);
            this.btn_fechar.Name = "btn_fechar";
            this.btn_fechar.Size = new System.Drawing.Size(528, 71);
            this.btn_fechar.TabIndex = 4;
            this.btn_fechar.Text = "Fechar";
            this.btn_fechar.UseVisualStyleBackColor = false;
            this.btn_fechar.Click += new System.EventHandler(this.btn_fechar_Click);
            // 
            // btn_prod
            // 
            this.btn_prod.BackColor = System.Drawing.Color.Black;
            this.btn_prod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_prod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_prod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_prod.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_prod.ForeColor = System.Drawing.Color.White;
            this.btn_prod.Image = ((System.Drawing.Image)(resources.GetObject("btn_prod.Image")));
            this.btn_prod.Location = new System.Drawing.Point(289, 44);
            this.btn_prod.Name = "btn_prod";
            this.btn_prod.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_prod.Size = new System.Drawing.Size(225, 175);
            this.btn_prod.TabIndex = 5;
            this.btn_prod.Text = "Produtos";
            this.btn_prod.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_prod.UseVisualStyleBackColor = false;
            this.btn_prod.Click += new System.EventHandler(this.btn_prod_Click);
            // 
            // btn_client
            // 
            this.btn_client.BackColor = System.Drawing.Color.Black;
            this.btn_client.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_client.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_client.ForeColor = System.Drawing.Color.White;
            this.btn_client.Image = ((System.Drawing.Image)(resources.GetObject("btn_client.Image")));
            this.btn_client.Location = new System.Drawing.Point(289, 268);
            this.btn_client.Name = "btn_client";
            this.btn_client.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_client.Size = new System.Drawing.Size(225, 175);
            this.btn_client.TabIndex = 6;
            this.btn_client.Text = "Clientes";
            this.btn_client.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_client.UseVisualStyleBackColor = false;
            this.btn_client.Click += new System.EventHandler(this.btn_client_Click);
            // 
            // btn_func
            // 
            this.btn_func.BackColor = System.Drawing.Color.Black;
            this.btn_func.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_func.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_func.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_func.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_func.ForeColor = System.Drawing.Color.White;
            this.btn_func.Image = ((System.Drawing.Image)(resources.GetObject("btn_func.Image")));
            this.btn_func.Location = new System.Drawing.Point(592, 268);
            this.btn_func.Name = "btn_func";
            this.btn_func.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_func.Size = new System.Drawing.Size(225, 175);
            this.btn_func.TabIndex = 7;
            this.btn_func.Text = "Funcionários";
            this.btn_func.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_func.UseVisualStyleBackColor = false;
            this.btn_func.Click += new System.EventHandler(this.btn_func_Click);
            // 
            // frm_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1102, 583);
            this.Controls.Add(this.btn_func);
            this.Controls.Add(this.btn_client);
            this.Controls.Add(this.btn_prod);
            this.Controls.Add(this.btn_fechar);
            this.Controls.Add(this.btn_caixa);
            this.Name = "frm_menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btn_caixa;
        private System.Windows.Forms.Button btn_fechar;
        private System.Windows.Forms.Button btn_prod;
        private System.Windows.Forms.Button btn_client;
        private System.Windows.Forms.Button btn_func;
    }
}