﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Padaria
{
    public partial class frm_prod : Form
    {
        public frm_prod()
        {
            InitializeComponent();
        }



        private void btn_exc_prod_Click(object sender, EventArgs e)
        {
            frm_excluir excluir = new frm_excluir();
            excluir.Show();
        }

        private void btn_cad_prod_Click_1(object sender, EventArgs e)
        {
            frm_cad_prod cadastro = new frm_cad_prod();
            cadastro.Show();
        }

        private void btn_mod_prod_Click_1(object sender, EventArgs e)
        {
            frm_mod_prod modificar = new frm_mod_prod();
            modificar.Show();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
