﻿
namespace Padaria
{
    partial class frm_func
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_func));
            this.btn_exc_func = new System.Windows.Forms.Button();
            this.btn_mod_func = new System.Windows.Forms.Button();
            this.btn_cad_func = new System.Windows.Forms.Button();
            this.btn_fechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_exc_func
            // 
            this.btn_exc_func.BackColor = System.Drawing.Color.Black;
            this.btn_exc_func.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_exc_func.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exc_func.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exc_func.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_exc_func.ForeColor = System.Drawing.Color.White;
            this.btn_exc_func.Image = ((System.Drawing.Image)(resources.GetObject("btn_exc_func.Image")));
            this.btn_exc_func.Location = new System.Drawing.Point(350, 105);
            this.btn_exc_func.Name = "btn_exc_func";
            this.btn_exc_func.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_exc_func.Size = new System.Drawing.Size(225, 175);
            this.btn_exc_func.TabIndex = 17;
            this.btn_exc_func.Text = "Excluir Funcionário";
            this.btn_exc_func.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_exc_func.UseVisualStyleBackColor = false;
            this.btn_exc_func.Click += new System.EventHandler(this.btn_exc_func_Click_1);
            // 
            // btn_mod_func
            // 
            this.btn_mod_func.BackColor = System.Drawing.Color.Black;
            this.btn_mod_func.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_mod_func.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_mod_func.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mod_func.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_mod_func.ForeColor = System.Drawing.Color.White;
            this.btn_mod_func.Image = ((System.Drawing.Image)(resources.GetObject("btn_mod_func.Image")));
            this.btn_mod_func.Location = new System.Drawing.Point(641, 105);
            this.btn_mod_func.Name = "btn_mod_func";
            this.btn_mod_func.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_mod_func.Size = new System.Drawing.Size(225, 175);
            this.btn_mod_func.TabIndex = 16;
            this.btn_mod_func.Text = "Modificar Funcionário";
            this.btn_mod_func.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_mod_func.UseVisualStyleBackColor = false;
            this.btn_mod_func.Click += new System.EventHandler(this.btn_mod_func_Click_1);
            // 
            // btn_cad_func
            // 
            this.btn_cad_func.BackColor = System.Drawing.Color.Black;
            this.btn_cad_func.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_cad_func.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_cad_func.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cad_func.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_cad_func.ForeColor = System.Drawing.Color.White;
            this.btn_cad_func.Image = ((System.Drawing.Image)(resources.GetObject("btn_cad_func.Image")));
            this.btn_cad_func.Location = new System.Drawing.Point(50, 105);
            this.btn_cad_func.Name = "btn_cad_func";
            this.btn_cad_func.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_cad_func.Size = new System.Drawing.Size(225, 175);
            this.btn_cad_func.TabIndex = 15;
            this.btn_cad_func.Text = "Cadastrar Funcionário";
            this.btn_cad_func.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_cad_func.UseVisualStyleBackColor = false;
            this.btn_cad_func.Click += new System.EventHandler(this.btn_cad_func_Click_1);
            // 
            // btn_fechar
            // 
            this.btn_fechar.BackColor = System.Drawing.Color.Transparent;
            this.btn_fechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_fechar.Font = new System.Drawing.Font("Century Gothic", 25.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_fechar.Location = new System.Drawing.Point(50, 344);
            this.btn_fechar.Name = "btn_fechar";
            this.btn_fechar.Size = new System.Drawing.Size(816, 71);
            this.btn_fechar.TabIndex = 18;
            this.btn_fechar.Text = "Fechar";
            this.btn_fechar.UseVisualStyleBackColor = false;
            this.btn_fechar.Click += new System.EventHandler(this.btn_fechar_Click);
            // 
            // frm_func
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(916, 475);
            this.Controls.Add(this.btn_fechar);
            this.Controls.Add(this.btn_exc_func);
            this.Controls.Add(this.btn_mod_func);
            this.Controls.Add(this.btn_cad_func);
            this.Name = "frm_func";
            this.Text = "Funcionários";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_exc_func;
        private System.Windows.Forms.Button btn_mod_func;
        private System.Windows.Forms.Button btn_cad_func;
        private System.Windows.Forms.Button btn_fechar;
    }
}