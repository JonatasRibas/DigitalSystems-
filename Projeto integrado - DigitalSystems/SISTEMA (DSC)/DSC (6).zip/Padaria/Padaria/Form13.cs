﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Padaria
{
    public partial class frm_cad_func : Form
    {
        public frm_cad_func()
        {
            InitializeComponent();
        }

        private void btn_cad_Click(object sender, EventArgs e)
        {
            if (txt_nome.Text == "")
            {
                MessageBox.Show("O campo 'Nome' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (combo_cargo.Text == "")
            {
                MessageBox.Show("O campo 'Cargo' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_email.Text == "")
            {
                MessageBox.Show("O campo 'Email' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_salario.Text == "")
            {
                MessageBox.Show("O campo 'Salário' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_nasc.Text == "")
            {
                MessageBox.Show("O campo 'Data de nascimento' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_cel.Text == "")
            {
                MessageBox.Show("O campo 'Celular' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Funcionário cadastrado com sucesso", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                combo_cargo.Text = "";
                txt_nome.Text = "";
                txt_nasc.Text = "";
                txt_email.Text = "";
                txt_cel.Text = "";
                txt_salario.Text = "";
            }
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
