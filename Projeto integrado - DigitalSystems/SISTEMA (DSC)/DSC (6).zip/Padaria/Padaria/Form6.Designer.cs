﻿
namespace Padaria
{
    partial class frm_caixa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_compra = new System.Windows.Forms.Button();
            this.btn_add_prod = new System.Windows.Forms.Button();
            this.txt_codigo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_quant = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_compra
            // 
            this.btn_compra.BackColor = System.Drawing.Color.Black;
            this.btn_compra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_compra.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_compra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_compra.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_compra.ForeColor = System.Drawing.Color.White;
            this.btn_compra.Location = new System.Drawing.Point(125, 280);
            this.btn_compra.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_compra.Name = "btn_compra";
            this.btn_compra.Size = new System.Drawing.Size(451, 43);
            this.btn_compra.TabIndex = 17;
            this.btn_compra.Text = "Finalizar Compra";
            this.btn_compra.UseVisualStyleBackColor = false;
            this.btn_compra.Click += new System.EventHandler(this.btn_compra_Click);
            // 
            // btn_add_prod
            // 
            this.btn_add_prod.BackColor = System.Drawing.Color.Transparent;
            this.btn_add_prod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_add_prod.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_add_prod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add_prod.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_add_prod.ForeColor = System.Drawing.Color.Black;
            this.btn_add_prod.Location = new System.Drawing.Point(125, 96);
            this.btn_add_prod.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_add_prod.Name = "btn_add_prod";
            this.btn_add_prod.Size = new System.Drawing.Size(451, 43);
            this.btn_add_prod.TabIndex = 16;
            this.btn_add_prod.Text = "Adicionar Produto";
            this.btn_add_prod.UseVisualStyleBackColor = false;
            this.btn_add_prod.Click += new System.EventHandler(this.btn_add_prod_Click);
            // 
            // txt_codigo
            // 
            this.txt_codigo.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_codigo.Location = new System.Drawing.Point(229, 30);
            this.txt_codigo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_codigo.Name = "txt_codigo";
            this.txt_codigo.Size = new System.Drawing.Size(347, 32);
            this.txt_codigo.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(125, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 23);
            this.label5.TabIndex = 14;
            this.label5.Text = "Código:";
            // 
            // txt_quant
            // 
            this.txt_quant.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_quant.Location = new System.Drawing.Point(280, 63);
            this.txt_quant.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_quant.Name = "txt_quant";
            this.txt_quant.Size = new System.Drawing.Size(296, 32);
            this.txt_quant.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(125, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 23);
            this.label1.TabIndex = 18;
            this.label1.Text = "Quantidade:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(125, 144);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(451, 131);
            this.dataGridView1.TabIndex = 20;
            // 
            // frm_caixa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(700, 338);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_quant);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_compra);
            this.Controls.Add(this.btn_add_prod);
            this.Controls.Add(this.txt_codigo);
            this.Controls.Add(this.label5);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frm_caixa";
            this.Text = "Caixa";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_compra;
        private System.Windows.Forms.Button btn_add_prod;
        private System.Windows.Forms.TextBox txt_codigo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_quant;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}