﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Padaria
{
    public partial class frm_client : Form
    {
        public frm_client()
        {
            InitializeComponent();
        }

        private void btn_cad_client_Click(object sender, EventArgs e)
        {

        }
    }
}
