﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Padaria
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_entrar_Click(object sender, EventArgs e)
        {
            if (txt_nome.Text == "")
            {
                MessageBox.Show("O campo 'Nome' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_senha.Text == "")
            {
                MessageBox.Show("O campo 'Senha' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                frm_menu menu = new frm_menu();
                menu.Show();
            }
        }
    }
}
