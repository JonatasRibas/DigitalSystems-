﻿
namespace Padaria
{
    partial class frm_prod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_prod));
            this.btn_exc_prod = new System.Windows.Forms.Button();
            this.btn_mod_prod = new System.Windows.Forms.Button();
            this.btn_cad_prod = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_exc_prod
            // 
            this.btn_exc_prod.BackColor = System.Drawing.Color.Black;
            this.btn_exc_prod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_exc_prod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exc_prod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exc_prod.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_exc_prod.ForeColor = System.Drawing.Color.White;
            this.btn_exc_prod.Image = ((System.Drawing.Image)(resources.GetObject("btn_exc_prod.Image")));
            this.btn_exc_prod.Location = new System.Drawing.Point(346, 183);
            this.btn_exc_prod.Name = "btn_exc_prod";
            this.btn_exc_prod.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_exc_prod.Size = new System.Drawing.Size(225, 175);
            this.btn_exc_prod.TabIndex = 5;
            this.btn_exc_prod.Text = "Excluir Produto";
            this.btn_exc_prod.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_exc_prod.UseVisualStyleBackColor = false;
            this.btn_exc_prod.Click += new System.EventHandler(this.btn_exc_prod_Click);
            // 
            // btn_mod_prod
            // 
            this.btn_mod_prod.BackColor = System.Drawing.Color.Black;
            this.btn_mod_prod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_mod_prod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_mod_prod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mod_prod.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_mod_prod.ForeColor = System.Drawing.Color.White;
            this.btn_mod_prod.Image = ((System.Drawing.Image)(resources.GetObject("btn_mod_prod.Image")));
            this.btn_mod_prod.Location = new System.Drawing.Point(638, 183);
            this.btn_mod_prod.Name = "btn_mod_prod";
            this.btn_mod_prod.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_mod_prod.Size = new System.Drawing.Size(225, 175);
            this.btn_mod_prod.TabIndex = 4;
            this.btn_mod_prod.Text = "Modificar Produto";
            this.btn_mod_prod.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_mod_prod.UseVisualStyleBackColor = false;
            this.btn_mod_prod.Click += new System.EventHandler(this.btn_mod_prod_Click_1);
            // 
            // btn_cad_prod
            // 
            this.btn_cad_prod.BackColor = System.Drawing.Color.Black;
            this.btn_cad_prod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_cad_prod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_cad_prod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cad_prod.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_cad_prod.ForeColor = System.Drawing.Color.White;
            this.btn_cad_prod.Image = ((System.Drawing.Image)(resources.GetObject("btn_cad_prod.Image")));
            this.btn_cad_prod.Location = new System.Drawing.Point(47, 183);
            this.btn_cad_prod.Name = "btn_cad_prod";
            this.btn_cad_prod.Padding = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.btn_cad_prod.Size = new System.Drawing.Size(225, 175);
            this.btn_cad_prod.TabIndex = 3;
            this.btn_cad_prod.Text = "Cadastrar Produto";
            this.btn_cad_prod.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_cad_prod.UseVisualStyleBackColor = false;
            this.btn_cad_prod.Click += new System.EventHandler(this.btn_cad_prod_Click_1);
            // 
            // frm_prod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(914, 600);
            this.Controls.Add(this.btn_exc_prod);
            this.Controls.Add(this.btn_mod_prod);
            this.Controls.Add(this.btn_cad_prod);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frm_prod";
            this.Text = "Produtos";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_exc_prod;
        private System.Windows.Forms.Button btn_mod_prod;
        private System.Windows.Forms.Button btn_cad_prod;
    }
}