﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Padaria
{
    public partial class frm_client : Form
    {
        public frm_client()
        {
            InitializeComponent();
        }

        private void btn_cad_client_Click(object sender, EventArgs e)
        {
            frm_cad_client cadastro = new frm_cad_client();
            cadastro.Show();
        }

        private void btn_exc_client_Click(object sender, EventArgs e)
        {
            frm_exc_client excluir = new frm_exc_client();
            excluir.Show();
        }

        private void btn_mod_client_Click(object sender, EventArgs e)
        {
            frm_mod_client modificar = new frm_mod_client();
            modificar.Show();
        }
    }
}
