﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Padaria
{
    public partial class frm_menu : Form
    {
        public frm_menu()
        {
            InitializeComponent();
        }


        private void btn_caixa_Click(object sender, EventArgs e)
        {
            frm_caixa caixa = new frm_caixa();
            caixa.Show();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_prod_Click(object sender, EventArgs e)
        {
            frm_prod produtos = new frm_prod();
            produtos.Show();
        }

        private void btn_func_Click(object sender, EventArgs e)
        {
            frm_func funcionarios = new frm_func();
            funcionarios.Show();
        }

        private void btn_client_Click(object sender, EventArgs e)
        {
            frm_client clientes = new frm_client();
            clientes.Show();
        }
    }
}
