﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Padaria
{
    public partial class frm_func : Form
    {
        public frm_func()
        {
            InitializeComponent();
        }

        private void btn_cad_func_Click(object sender, EventArgs e)
        {
            frm_cad_func cadastro = new frm_cad_func();
            cadastro.Show();
        }

        private void btn_exc_func_Click(object sender, EventArgs e)
        {
            frm_exc_func excluir = new frm_exc_func();
            excluir.Show();
        }

        private void btn_mod_func_Click(object sender, EventArgs e)
        {
            frm_mod_func modificar = new frm_mod_func();
            modificar.Show();
        }
    }
}
