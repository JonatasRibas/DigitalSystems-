﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Padaria
{
    public partial class frm_caixa : Form
    {
        public frm_caixa()
        {
            InitializeComponent();
        }

        private void btn_compra_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Compra finalizada com sucesso", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_add_prod_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("O campo 'Código' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
