﻿
namespace Padaria
{
    partial class frm_func
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_func));
            this.btn_exc_func = new System.Windows.Forms.Button();
            this.btn_mod_func = new System.Windows.Forms.Button();
            this.btn_cad_func = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_exc_func
            // 
            this.btn_exc_func.BackColor = System.Drawing.Color.Black;
            this.btn_exc_func.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_exc_func.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exc_func.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exc_func.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_exc_func.ForeColor = System.Drawing.Color.White;
            this.btn_exc_func.Image = ((System.Drawing.Image)(resources.GetObject("btn_exc_func.Image")));
            this.btn_exc_func.Location = new System.Drawing.Point(305, 160);
            this.btn_exc_func.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_exc_func.Name = "btn_exc_func";
            this.btn_exc_func.Padding = new System.Windows.Forms.Padding(0, 0, 0, 11);
            this.btn_exc_func.Size = new System.Drawing.Size(197, 131);
            this.btn_exc_func.TabIndex = 8;
            this.btn_exc_func.Text = "Excluir Funcionário";
            this.btn_exc_func.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_exc_func.UseVisualStyleBackColor = false;
            // 
            // btn_mod_func
            // 
            this.btn_mod_func.BackColor = System.Drawing.Color.Black;
            this.btn_mod_func.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_mod_func.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_mod_func.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mod_func.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_mod_func.ForeColor = System.Drawing.Color.White;
            this.btn_mod_func.Image = ((System.Drawing.Image)(resources.GetObject("btn_mod_func.Image")));
            this.btn_mod_func.Location = new System.Drawing.Point(560, 160);
            this.btn_mod_func.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_mod_func.Name = "btn_mod_func";
            this.btn_mod_func.Padding = new System.Windows.Forms.Padding(0, 0, 0, 11);
            this.btn_mod_func.Size = new System.Drawing.Size(197, 131);
            this.btn_mod_func.TabIndex = 7;
            this.btn_mod_func.Text = "Modificar Funcionário";
            this.btn_mod_func.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_mod_func.UseVisualStyleBackColor = false;
            // 
            // btn_cad_func
            // 
            this.btn_cad_func.BackColor = System.Drawing.Color.Black;
            this.btn_cad_func.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_cad_func.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_cad_func.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cad_func.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_cad_func.ForeColor = System.Drawing.Color.White;
            this.btn_cad_func.Image = ((System.Drawing.Image)(resources.GetObject("btn_cad_func.Image")));
            this.btn_cad_func.Location = new System.Drawing.Point(43, 160);
            this.btn_cad_func.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_cad_func.Name = "btn_cad_func";
            this.btn_cad_func.Padding = new System.Windows.Forms.Padding(0, 0, 0, 11);
            this.btn_cad_func.Size = new System.Drawing.Size(197, 131);
            this.btn_cad_func.TabIndex = 6;
            this.btn_cad_func.Text = "Cadastrar Funcionário";
            this.btn_cad_func.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_cad_func.UseVisualStyleBackColor = false;
            // 
            // frm_func
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_exc_func);
            this.Controls.Add(this.btn_mod_func);
            this.Controls.Add(this.btn_cad_func);
            this.Enabled = false;
            this.Name = "frm_func";
            this.Text = "Funcionários";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_exc_func;
        private System.Windows.Forms.Button btn_mod_func;
        private System.Windows.Forms.Button btn_cad_func;
    }
}