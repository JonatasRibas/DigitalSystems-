﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Padaria
{
    public partial class frm_mod_client : Form
    {
        public frm_mod_client()
        {
            InitializeComponent();
        }

        private void btn_mod_client_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("O campo 'Código' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_nome.Text == "")
            {
                MessageBox.Show("O campo 'Nome' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_cpf.Text == "")
            {
                MessageBox.Show("O campo 'CPF' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_email.Text == "")
            {
                MessageBox.Show("O campo 'Email' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_cidade.Text == "")
            {
                MessageBox.Show("O campo 'Cidade' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txt_nasc.Text == "")
            {
                MessageBox.Show("O campo 'Data de nascimento' deve ser preenchido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Cliente modificado com sucesso", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txt_codigo.Text = "";
                txt_cidade.Text = "";
                txt_nome.Text = "";
                txt_nasc.Text = "";
                txt_email.Text = "";
                txt_cpf.Text = "";
            }
        }
    }
}
